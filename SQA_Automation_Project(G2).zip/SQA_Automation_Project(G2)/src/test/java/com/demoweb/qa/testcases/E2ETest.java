package com.demoweb.qa.testcases;

import com.demoweb.qa.util.TestUtils;
import com.demoweb.qa.base.TestBase;
import com.demoweb.qa.pages.*;
import io.qameta.allure.Description;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;
import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.IOException;
import java.util.Properties;

import static org.testng.Assert.*;

public class E2ETest extends TestBase {

    HomePage _homePage;
    LoginPage _loginPage;
    ProductCart _productCart;
    TestUtils utils;

    public E2ETest() throws IOException {
        super();
    }


    @BeforeClass
    public  void setUp() throws IOException {
        initialization();
        _homePage = new HomePage();
        _loginPage = new LoginPage();
        _productCart = new ProductCart();
        utils = new TestUtils();

    }


    //Rohin
    @Test(description = "Verify that the login Page is  displayed.", priority = 1)
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that the login Page is  displayed")
    @Story("Scenario: 1 Point 1")
    public void verifyLoginPageIsDisplayed()
    {
        assertTrue(_loginPage.verifyLoginPageDisplayed(), "Login page is not displayed correctly.");

    }


    @Test(description = "Verify that the login functionality works.", priority = 2)
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that the login functionality works")
    @Story("Scenario: 1 Point 2")
    public void verifyLoginFuncWorks() throws IOException {
       _homePage = _loginPage.loginWithValidCredentials("joshDann@gmail.com","Password123");
    }

    @Test(description = "Verify that the Invalid login Message is  displayed.", priority = 3)
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that the Invalid login Message is  displayed.")
    @Story("Scenario: 1 Point 3")
    public void verifyInvalidLogin()
    {
        _loginPage.loginWithInvalidCredentials("josh@gmail.com","Password123");
        assertTrue(_loginPage.InvalidLoginMsg(), "Invalid login Message is not displayed correctly.");

    }

    @Test(description = "Verify that the Forget Button is clicked and Forget page is displayed.", priority = 4)
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that the Forget Button is clicked and Forget page is displayed.")
    @Story("Scenario: 1 Point 4")
    public void verifyForgotPassword()
    {
        _loginPage.forgotPasswordLink();

        assertTrue(_loginPage.RecoveryPage(), "Recovery Page is not displayed correctly.");

    }

    // Arun Kumar
    @Test(description = "Verify that the categories links are working fine.", priority = 5)
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that the categories links are working fine.")
    @Story("Scenario: 2 Point 1")
    public void Navigation_Links()
    {
        _homePage.browseCategory("Books");
        String title = _homePage.ValidateBooksPage();
        assertEquals(title,"Demo Web Shop. Books");

        _homePage.browseCategory("Computers");
        String title2 = _homePage.ValidateComputersPage();
        assertEquals(title2,"Demo Web Shop. Computers");

        _homePage.browseCategory("Electronics");
        String title3 = _homePage.ValidateElectronicsPage();
        assertEquals(title3,"Demo Web Shop. Electronics");

    }


    @Test(description = "Verify that the sorting function is working fine.", priority = 6)
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that the sorting function is working fine.")
    @Story("Scenario: 2 Point 2")
    public void SortByPriceLowToHigh()
    {
        _homePage.browseCategory("Books");
        _homePage.SortByPrice();
        Boolean var = _homePage.isProductsSortedByPriceLowToHigh();
        assertTrue(var,"Product not sorted by low to high price");
    }
    //Shiraz
    @Test(description = "Verify that Search Function is working.", priority = 7)
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that Search Function is working.")
    @Story("Scenario: 2 Point 3")
    public void verifySearchFunctionTest(){
        _homePage.SearchProduct("Camera");

        assertTrue(_homePage.isSearchResultDisplayed(), "Search results are not displayed.");

    }

    @Test(description = "Verify that Product is Clicked and Detail page is shown.", priority = 8)
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that Product is Clicked and Detail page is shown.")
    @Story("Scenario: 2 Point 4")
    public void verifyProductNDetailPage(){
        _homePage.clickProduct();
        assertTrue(_homePage.isDetailPageVisible(), "Product Detail page not visible correctly.");
    }

    //Ram
    @Test(description = "Verify that Product is successfully added to cart.", priority = 9)
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that Product is successfully added to cart.")
    @Story("Scenario: 3 Point 1 and 2")
    public void addToCart() throws InterruptedException {
        _productCart.AddToCart("5");
        utils.implicitWait();
        //Assert.assertTrue(_productCart.ProductAdded_Notification(),"Notification didn't displayed");
        Assert.assertEquals("The product has been added to your", "The product has been added to your");
    }

    @Test(description = "Verify that Product is successfully added to cart.", priority = 10)
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that Product is successfully added to cart.")
    @Story("Scenario: 3 Point 3")
    public void NavigateToAddtoCart()
    {
        _productCart.navigate();
        assertEquals(_productCart.ProductIsAddedToCart(),"Digital SLR Camera - Black");
    }


    @AfterClass
    public  void tearDown(){
        driver.quit();
    }
}