package com.demoweb.qa.pages;

import org.openqa.selenium.support.FindBy;
import com.demoweb.qa.base.TestBase;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;


public class ProductCart extends TestBase {

    public ProductCart() throws IOException {
        super();
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//input[@id='addtocart_18_EnteredQuantity']")
    WebElement quantity;
    @FindBy(xpath = "//input[@id='add-to-cart-button-18']")
    WebElement BtnCart;
    @FindBy(xpath = "//p[contains(text(),'The product has been added to your ')]")
    WebElement notification;

    @FindBy(xpath = "(//span[@class=\"cart-label\"])[1]")
    WebElement shoppingcart;

    @FindBy(xpath = "//a[@class='product-name']")
    WebElement ProductName;

    public void AddToCart(String item_q)
    {
        quantity.clear(); // Clear the default value
        quantity.sendKeys(item_q);
        BtnCart.click();
    }

    public boolean ProductAdded_Notification()
    {
        return notification.isDisplayed();
    }

    public void navigate()
    {
        shoppingcart.click();
    }

    public String ProductIsAddedToCart()
    {
        return ProductName.getText();
    }




}