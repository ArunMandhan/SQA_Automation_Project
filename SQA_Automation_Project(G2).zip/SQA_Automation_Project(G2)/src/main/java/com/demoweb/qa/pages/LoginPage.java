package com.demoweb.qa.pages;

import com.demoweb.qa.base.TestBase;
import com.sun.org.apache.xpath.internal.res.XPATHErrorResources;
import org.apache.xmlbeans.impl.xb.xsdschema.SelectorDocument;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import sun.security.util.Password;

import java.io.IOException;


public class LoginPage extends TestBase {
    public LoginPage() throws IOException {
        super();
        PageFactory.initElements(driver, this);
    }
    @FindBy(xpath = "//a[@href='/login']")
    WebElement _HloginBtn;

    @FindBy( xpath= "//input[@id='Email']")
    WebElement _Email;

    @FindBy(xpath = "//input[@id='Password']")
    WebElement loginPass;

    @FindBy(xpath = "//input[@class='button-1 login-button']")
    WebElement Login;

    @FindBy(xpath = "//a[@href='/logout']")
    WebElement _logOutBtn;

    @FindBy(xpath = "//span[contains(text(), 'Login was unsuccessful. Please correct the errors and try again.')]")
    WebElement InvalidLogin;


    @FindBy(xpath = "//a[text()='Forgot password?']")
    WebElement Forgot;

    @FindBy(xpath="//h1[text()='Password recovery']")
    WebElement RecoveryPage;





    public boolean verifyLoginPageDisplayed()
    {
        // Click on the Login link
        _HloginBtn.click();
       // return true;
     Boolean flag = Login.isDisplayed();
        if(!flag) return false;

        return true;

    }
    public HomePage loginWithValidCredentials(String Email, String Password) throws IOException {
        // Enter valid email and password
        _Email.sendKeys(Email);
        loginPass.sendKeys(Password);

        // Click on the Login button
        Login.click();
        return  new HomePage();

    }


    public void loginWithInvalidCredentials(String Email, String Password)
    {
        //logout First
        _logOutBtn.click();
        _HloginBtn.click();


        // Enter invalid email and password
        _Email.sendKeys(Email);
        loginPass.sendKeys(Password);

        // Click on the Login button
        Login.click();

    }
    public boolean InvalidLoginMsg(){
        return InvalidLogin.isDisplayed();
    }


    public void forgotPasswordLink() {
        // Click on the Forgot password link
        Forgot.click();

        // Assert that the forgot password page is displayed
        // You can add additional assertions or verifications here based on your application's behavior
    }

    public boolean RecoveryPage(){
       return RecoveryPage.isDisplayed();
    }




}


