package com.demoweb.qa.pages;

import  com.demoweb.qa.pages.*;
import com.demoweb.qa.base.TestBase;
import org.apache.xmlbeans.impl.store.Path;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.io.IOException;

public class HomePage extends TestBase {

    //Arun
    @FindBy(xpath = "//select[@id='products-orderby']")
    WebElement SortBy;


    //shiraz

    @FindBy(
            xpath = "//*[@id=\"small-searchterms\"]"
    )
    WebElement searchItems;

    @FindBy(xpath="//input[@type='submit']")
    WebElement SearchBtn;

    @FindBy(xpath="//div[@class='product-grid']")
    WebElement SearchResult;

    @FindBy(xpath="//*[contains(h1,'$25')]")
    WebElement PDetailPage;

    @FindBy(xpath = "//a[contains(@title,'Show details for $25')]")
    WebElement GetProduct;
    public HomePage() throws IOException {
        PageFactory.initElements(driver, this);
    }

    //Arun Kumar
    public void browseCategory(String category) {
        WebElement categoryLink = driver.findElement(By.xpath("//div[@class='listbox']/ul/li/a[contains(text(), '" + category + "')]"));
        categoryLink.click();
    }

    public String ValidateBooksPage()
    {
        return driver.getTitle();
    }
    public String ValidateComputersPage()
    {
        return driver.getTitle();
    }
    public String ValidateElectronicsPage()
    {
        return driver.getTitle();
    }

    public void SortByPrice()
    {
        Select sortOption = new Select(SortBy);
        sortOption.selectByVisibleText("Price: Low to High");

        // Wait for the page to reload and products to be sorted
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='product-item']//span[@class='price actual-price']")));
    }

    public boolean isProductsSortedByPriceLowToHigh() {
        // Check the sorting order of the products based on the prices
        WebElement firstProductPrice = driver.findElement(By.xpath("//div[@class='prices']//span[@class='price actual-price']"));
        WebElement secondProductPrice = driver.findElement(By.xpath("(//div[@class='prices']//span[@class='price actual-price'])[4]"));

        double firstPrice = Double.parseDouble(firstProductPrice.getText().substring(1));
        double secondPrice = Double.parseDouble(secondProductPrice.getText().substring(1));

        return firstPrice <= secondPrice;
    }

    //shiraz
    public void SearchProduct(String _SearchProd){
        searchItems.sendKeys(_SearchProd);
        SearchBtn.click();
    }
    public boolean isSearchResultDisplayed() {
        return SearchResult.isDisplayed();
    }

    public  void clickProduct(){
        GetProduct.click();
    }
    public boolean isDetailPageVisible(){
        return PDetailPage.isDisplayed();
    }
}
