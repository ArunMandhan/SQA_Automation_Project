package com.demoweb.qa.testcases;

import com.demoweb.qa.base.TestBase;
import com.demoweb.qa.pages.HomePage;
import io.qameta.allure.Description;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;
import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.IOException;

public class E2ETest extends TestBase {
     HomePage _homePage;
    public E2ETest() throws IOException {
        super();
    }


    @BeforeClass
    public  void setUp() throws IOException {
        initialization();
        _homePage = new HomePage();
        

    }

    // Arun Kumar
    @Test(description = "Verify that the categories links are working fine.",
    priority = 1)
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that the categories links are working fine.")
    @Story("Scenario: 2 Point 1")
    public void Books()
    {
        _homePage.browseCategory("Books");
        String title = _homePage.ValidateBooksPage();
        Assert.assertEquals(title,"Demo Web Shop. Books");
    }

    @Test(description = "Verify that the categories links are working fine.",
            priority = 1)
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that the categories links are working fine.")
    @Story("Scenario: 2 Point 1")
    public void Computers()
    {
        _homePage.browseCategory("Computers");
        String title = _homePage.ValidateComputersPage();
        Assert.assertEquals(title,"Demo Web Shop. Computers");

    }
    @Test(description = "Verify that the categories links are working fine.",
            priority = 1)
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that the categories links are working fine.")
    @Story("Scenario: 2 Point 1")
    public void Electronics()
    {
        _homePage.browseCategory("Electronics");
        String title = _homePage.ValidateElectronicsPage();
        Assert.assertEquals(title,"Demo Web Shop. Electronics");
    }

    @Test(description = "Verify that the sorting function is working fine.",
            priority = 1)
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that the sorting function is working fine.")
    @Story("Scenario: 2 Point 2")
    public void SortByPriceLowToHigh()
    {
        _homePage.browseCategory("Books");
        _homePage.SortByPrice();
        Boolean var= _homePage.isProductsSortedByPriceLowToHigh();
        Assert.assertTrue(var,"Product not sorted by low to high price");
    }
    //Shiraz
    @Test(
            description = "Verify that Search Function is working.",
            priority = 1)
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that Search Function is working.")
    @Story("Scenario: 2 Point 3")
    public void verifySearchFunctionTest(){
        _homePage.SearchProduct("Camera");

        Assert.assertTrue(_homePage.isSearchResultDisplayed(), "Search results are not displayed.");

    }

    @Test(
            description = "Verify that Product is Clicked and Detail page is shown.",
            priority = 2)
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that Product is Clicked and Detail page is shown.")
    @Story("Scenario: 2 Point 4")
    public void verifyProductNDetailPage(){
        driver.navigate().to("https://demowebshop.tricentis.com/");
        _homePage.clickProduct();
        Assert.assertTrue(_homePage.isDetailPageVisible(), "Product Detail page not visible correctly.");
    }


    @AfterClass
    public  void tearDown(){
        driver.quit();
    }
}
