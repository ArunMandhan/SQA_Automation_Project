package com.demoweb.qa.pages;
import com.demoweb.qa.base.TestBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.io.IOException;

public class HomePage extends TestBase {

    public HomePage() throws IOException {
        super();
        PageFactory.initElements(driver, this);
    }
    //Arun
    @FindBy(xpath = "//select[@id='products-orderby']")
    WebElement SortBy;

    By ActualPrice =  By.xpath("//div[@class='product-item']//span[@class='price actual-price']");

    By SecondActualPrice =  By.xpath("(//div[@class='product-item']//span[@class='price actual-price'])[4]");

    @FindBy(xpath = "//div[@class='listbox']/ul/li/a")
    WebElement categoryLink;



    //shiraz

    @FindBy(
            xpath = "//*[@id=\"small-searchterms\"]"
    )
    WebElement searchItems;

    @FindBy(xpath="//input[@type='submit']")
    WebElement SearchBtn;

    @FindBy(xpath="//h2[@class='product-title']/a")
    WebElement SearchResult;

    @FindBy(xpath="//h1[contains(text(),'Digital SLR Camera 12.2 Mpixel')]")
    WebElement PDetailPage;

    @FindBy(xpath = "//a[contains(@title,'Show details for $25')]")
    WebElement GetProduct;

    //Arun Kumar
    public void browseCategory(String category) {
        WebElement categoryLink = driver.findElement(By.xpath("//div[@class='listbox']/ul/li/a[contains(text(), '" + category + "')]"));
        categoryLink.click();
    }

//    public void browseCategory(String category) {
//        String xpath = String.format("//div[@class='listbox']/ul/li/a[contains(text(), '%s')]", category);
//        PageFactory.initElements(driver, this);
//        categoryLink = driver.findElement(By.xpath(xpath));
//        categoryLink.click();
//    }


    public String ValidateBooksPage()
    {
        return driver.getTitle();
    }
    public String ValidateComputersPage()
    {
        return driver.getTitle();
    }
    public String ValidateElectronicsPage()
    {
        return driver.getTitle();
    }

    public void SortByPrice()
    {
        Select sortOption = new Select(SortBy);
        sortOption.selectByVisibleText("Price: Low to High");

        // Wait for the page to reload and products to be sorted
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(ActualPrice));
    }

    public boolean isProductsSortedByPriceLowToHigh() {
        // Check the sorting order of the products based on the prices
        WebElement firstProductPrice = driver.findElement(ActualPrice);
        WebElement secondProductPrice = driver.findElement(SecondActualPrice);

        double firstPrice = Double.parseDouble(firstProductPrice.getText().substring(1));
        double secondPrice = Double.parseDouble(secondProductPrice.getText().substring(1));

        return firstPrice <= secondPrice;
    }

    //shiraz
    public void SearchProduct(String _SearchProd){
        searchItems.sendKeys(_SearchProd);
        SearchBtn.click();
    }
    public boolean isSearchResultDisplayed() {
        return SearchResult.isDisplayed();
    }

    public  void clickProduct(){
        SearchResult.click();
    }
    public boolean isDetailPageVisible(){
        return PDetailPage.isDisplayed();
    }
}